// Drop-Off Summary functionality
document.addEventListener('DOMContentLoaded', function() {
    // Initialize modal
    const summaryModal = new bootstrap.Modal(document.getElementById('dropoffSummaryModal'));
    
    // Attach click listeners to all dropoff summary buttons
    document.querySelectorAll('.btn-view-summary').forEach(btn => {
        btn.addEventListener('click', function(e) {
            e.preventDefault();
            const dropoffId = this.getAttribute('data-id');
            loadDropoffSummary(dropoffId);
        });
    });
    
    // Support the data-dropoff-id buttons in maintenance alerts page
    document.querySelectorAll('[data-bs-toggle="modal"][data-bs-target="#dropoffSummaryModal"]').forEach(btn => {
        btn.addEventListener('click', function(e) {
            e.preventDefault();
            const dropoffId = this.getAttribute('data-dropoff-id');
            if (dropoffId) {
                loadDropoffSummary(dropoffId);
            }
        });
    });
    
    // Print functionality
    document.getElementById('printSummaryBtn').addEventListener('click', function(e) {
        e.preventDefault();
        printSummary();
    });
    
    // Load summary data from the server
    function loadDropoffSummary(dropoffId) {
        // Update the edit button URL
        document.getElementById('editDropoffBtn').href = `/complete-dropoff/${dropoffId}`;
        
        // Show loading spinner
        document.getElementById('dropoffSummaryContent').innerHTML = `
            <div class="d-flex justify-content-center">
                <div class="spinner-border text-primary" role="status">
                    <span class="visually-hidden">Loading...</span>
                </div>
            </div>
        `;
        
        // Show the modal
        summaryModal.show();
        
        // Fetch the data
        fetch(`/dropoff-summary/${dropoffId}`)
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json();
            })
            .then(data => {
                displaySummary(data);
            })
            .catch(error => {
                document.getElementById('dropoffSummaryContent').innerHTML = `
                    <div class="alert alert-danger">
                        Error loading summary: ${error.message}
                    </div>
                `;
            });
    }
    
    // Display summary in the modal
    function displaySummary(data) {
        const dropoff = data.dropoff;
        const alerts = data.maintenance_alerts;
        
        // Format the content
        let content = `
        <style>
            .summary-container {
                color: #212529 !important;
            }
            .summary-container dl, 
            .summary-container dt, 
            .summary-container dd, 
            .summary-container p,
            .summary-container .card-body,
            .summary-container .table {
                color: #212529 !important;
            }
            /* Make card header headings explicitly white */
            .summary-container .card-header h5 {
                color: white !important;
            }
            .summary-container .badge.bg-success,
            .summary-container .badge.bg-danger,
            .summary-container .badge.bg-info {
                color: white !important;
            }
            .summary-container .badge.bg-warning {
                color: #212529 !important;
            }
            .summary-container .card-header.bg-dark,
            .summary-container .card-header.bg-danger {
                color: white !important;
            }
        </style>
        <div class="summary-container text-dark">
            <div class="row mb-4">
                <div class="col-md-6">
                    <div class="card border-dark">
                        <div class="card-header bg-dark text-white">
                            <h5 class="mb-0">Vehicle Information</h5>
                        </div>
                        <div class="card-body bg-white">
                            <dl class="row mb-0">
                                <dt class="col-sm-5">Registration:</dt>
                                <dd class="col-sm-7"><strong>${dropoff.rego || 'N/A'}</strong></dd>
                                
                                <dt class="col-sm-5">Customer Name:</dt>
                                <dd class="col-sm-7">${dropoff.name || 'N/A'}</dd>
                                
                                <dt class="col-sm-5">Staff Name:</dt>
                                <dd class="col-sm-7">${dropoff.staff_name || 'N/A'}</dd>
                                
                                <dt class="col-sm-5">Vehicle Category:</dt>
                                <dd class="col-sm-7">
                                    <span class="badge bg-info text-white">
                                        ${dropoff.vehicle_category || 'Not specified'}
                                    </span>
                                </dd>
                                
                                <dt class="col-sm-5">Status:</dt>
                                <dd class="col-sm-7">
                                    <span class="badge ${dropoff.status === 'Drop-Off Completed' ? 'bg-success text-white' : 'bg-warning text-dark'}">
                                        ${dropoff.status === 'Drop Off Completed' ? 'Drop-Off Completed' : dropoff.status === 'To be Dropped Off' ? 'To be Dropped-Off' : dropoff.status}
                                    </span>
                                </dd>
                                
                                <dt class="col-sm-5">Date Processed:</dt>
                                <dd class="col-sm-7">${dropoff.date_returned_formatted || 'N/A'}</dd>
                            </dl>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-6">
                    <div class="card border-dark">
                        <div class="card-header bg-dark text-white">
                            <h5 class="mb-0">Documentation</h5>
                        </div>
                        <div class="card-body bg-white">
                            <dl class="row mb-0">
                                <dt class="col-sm-5">Insurance Status:</dt>
                                <dd class="col-sm-7">${dropoff.insurance_status || 'N/A'}</dd>
                                
                                <dt class="col-sm-5">Rego Expiry:</dt>
                                <dd class="col-sm-7">${dropoff.rego_expiry_formatted || 'N/A'}</dd>
                                
                                <dt class="col-sm-5">COF Expiry:</dt>
                                <dd class="col-sm-7">${dropoff.cof_expiry_formatted || 'N/A'}</dd>
                                
                                <dt class="col-sm-5">Current RUCs:</dt>
                                <dd class="col-sm-7">${dropoff.current_rucs || 'N/A'}</dd>
                            </dl>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="row mb-4">
                <div class="col-md-6">
                    <div class="card border-dark">
                        <div class="card-header bg-dark text-white">
                            <h5 class="mb-0">Vehicle Condition</h5>
                        </div>
                        <div class="card-body bg-white">
                            <dl class="row mb-0">
                                <dt class="col-sm-5">Windscreen:</dt>
                                <dd class="col-sm-7">${dropoff.windscreen_condition || 'N/A'}</dd>
                                
                                <dt class="col-sm-5">Fuel Level:</dt>
                                <dd class="col-sm-7">
                                    ${dropoff.fuel_level ? dropoff.fuel_level + '%' : 'N/A'}
                                </dd>
                                
                                <dt class="col-sm-5">AdBlue Level:</dt>
                                <dd class="col-sm-7">${dropoff.adblue_level || 'N/A'}</dd>
                                
                                <dt class="col-sm-5">Damage Check:</dt>
                                <dd class="col-sm-7">${dropoff.damage_check || 'N/A'}</dd>
                                
                                <dt class="col-sm-5">Damage Areas:</dt>
                                <dd class="col-sm-7">${dropoff.damage_areas || 'None'}</dd>
                                
                                <dt class="col-sm-5">Customer Notes:</dt>
                                <dd class="col-sm-7">${dropoff.customer_notes || 'No notes provided'}</dd>
                                
                                <dt class="col-sm-5">Urgent Assessment:</dt>
                                <dd class="col-sm-7">
                                    <span class="badge ${dropoff.urgent_assessment === 'Yes' ? 'bg-danger text-white' : 'bg-success text-white'}">
                                        ${dropoff.urgent_assessment || 'No'}
                                    </span>
                                </dd>
                            </dl>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-6">
                    <div class="card border-dark">
                        <div class="card-header bg-dark text-white">
                            <h5 class="mb-0">Usage Information</h5>
                        </div>
                        <div class="card-body bg-white">
                            <dl class="row mb-0">
                                <dt class="col-sm-5">KM at Pickup:</dt>
                                <dd class="col-sm-7">${dropoff.km_pickup || 'N/A'}</dd>
                                
                                <dt class="col-sm-5">KM at Drop-Off:</dt>
                                <dd class="col-sm-7">${dropoff.km_dropoff || 'N/A'}</dd>
                                
                                <dt class="col-sm-5">Trip KM:</dt>
                                <dd class="col-sm-7">${dropoff.trip_km || 'N/A'}</dd>
                                
                                <dt class="col-sm-5">Service Due KM:</dt>
                                <dd class="col-sm-7">${dropoff.service_due_km || 'N/A'}</dd>
                                
                                <dt class="col-sm-5">Next Hire Date:</dt>
                                <dd class="col-sm-7">${dropoff.next_hire_date_formatted || 'N/A'}</dd>
                                
                                <dt class="col-sm-5">Next Hire Length:</dt>
                                <dd class="col-sm-7">${dropoff.next_hire_length ? dropoff.next_hire_length + ' days' : 'N/A'}</dd>
                                
                                ${dropoff.ruc_info ? `
                                <dt class="col-sm-5">RUCs Owed:</dt>
                                <dd class="col-sm-7">
                                    <span class="badge bg-warning text-dark">
                                        ${dropoff.ruc_info.formatted} (Driven: ${dropoff.ruc_info.trip_km} km — Diesel vehicle)
                                    </span>
                                </dd>` : ''}
                            </dl>
                        </div>
                    </div>
                </div>
            </div>
        `;
        
        // Add maintenance alerts if any
        if (alerts && alerts.length > 0) {
            content += `
            <div class="row">
                <div class="col-12">
                    <div class="card border-danger">
                        <div class="card-header bg-danger text-white">
                            <h5 class="mb-0">
                                <i class="fas fa-exclamation-triangle me-2"></i>
                                Maintenance Alerts (${alerts.length})
                            </h5>
                        </div>
                        <div class="card-body bg-white">
                            <div class="table-responsive">
                                <table class="table table-sm table-striped">
                                    <thead>
                                        <tr>
                                            <th>Issue Type</th>
                                            <th>Details</th>
                                            <th>Status</th>
                                            <th>Date Created</th>
                                        </tr>
                                    </thead>
                                    <tbody>
            `;
            
            alerts.forEach(alert => {
                content += `
                    <tr>
                        <td>${alert.issue_type}</td>
                        <td>${alert.details}</td>
                        <td>
                            <span class="badge ${alert.status === 'Pending' ? 'bg-warning text-dark' : 'bg-success text-white'}">${alert.status}</span>
                        </td>
                        <td>${alert.date_created}</td>
                    </tr>
                `;
            });
            
            content += `
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            `;
        }
        
        // Close the summary container
        content += `</div>`;
        
        // Update the modal content
        document.getElementById('dropoffSummaryContent').innerHTML = content;
    }
    
    // Print the summary
    function printSummary() {
        // Clone the summary content for printing
        const printContent = document.getElementById('dropoffSummaryContent').cloneNode(true);
        
        // Format date in British English format (DD/MM/YYYY - HH:MM am/pm)
        const now = new Date();
        const day = String(now.getDate()).padStart(2, '0');
        const month = String(now.getMonth() + 1).padStart(2, '0');
        const year = now.getFullYear();
        
        // Format time with 12-hour clock and am/pm in lowercase
        let hours = now.getHours();
        const ampm = hours >= 12 ? 'pm' : 'am';
        hours = hours % 12;
        hours = hours ? hours : 12; // Convert 0 to 12 for 12-hour format
        const minutes = String(now.getMinutes()).padStart(2, '0');
        
        const printDate = `${day}/${month}/${year} - ${hours}:${minutes} ${ampm}`;
        
        // Update the print template
        document.getElementById('printDate').innerText = `Generated on: ${printDate}`;
        document.getElementById('printContent').innerHTML = printContent.innerHTML;
        
        // Create a print window
        const printWindow = window.open('', '_blank');
        printWindow.document.write(`
            <html>
                <head>
                    <title>Vehicle Drop-Off Summary</title>
                    <link rel="stylesheet" href="https://cdn.replit.com/agent/bootstrap-agent-dark-theme.min.css">
                    <style>
                        body { padding: 20px; }
                        @media print {
                            .no-print { display: none !important; }
                        }
                        .summary-container {
                            color: #212529 !important;
                        }
                        .summary-container dl, 
                        .summary-container dt, 
                        .summary-container dd, 
                        .summary-container p,
                        .summary-container .card-body,
                        .summary-container .table,
                        /* Make card header headings explicitly white */
                        .summary-container .card-header h5 {
                            color: white !important;
                        }
                        .summary-container thead,
                        .summary-container tbody,
                        .summary-container tr,
                        .summary-container th,
                        .summary-container td {
                            color: #212529 !important;
                        }
                        .summary-container .badge.bg-success,
                        .summary-container .badge.bg-danger,
                        .summary-container .badge.bg-info {
                            color: white !important;
                        }
                        .summary-container .badge.bg-warning {
                            color: #212529 !important;
                        }
                        .summary-container .card-header.bg-dark,
                        .summary-container .card-header.bg-danger {
                            color: white !important;
                        }
                    </style>
                </head>
                <body class="bg-white text-dark" data-bs-theme="light">
                    <div class="text-dark">
                        ${document.getElementById('printTemplate').innerHTML}
                    </div>
                    <div class="text-center mt-4">
                        <button class="btn btn-primary no-print" onclick="window.print()">Print Now</button>
                        <button class="btn btn-secondary no-print ms-2" onclick="window.close()">Close</button>
                    </div>
                </body>
            </html>
        `);
        
        printWindow.document.close();
    }
});