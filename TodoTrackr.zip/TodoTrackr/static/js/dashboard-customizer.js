// Dashboard widget customizer
document.addEventListener('DOMContentLoaded', function() {
    const widgetContainer = document.getElementById('widget-container');
    const saveLayoutBtn = document.getElementById('save-layout-btn');
    const resetLayoutBtn = document.getElementById('reset-layout-btn');
    
    if (!widgetContainer) return;

    // Initialize Sortable.js on the widget container
    const sortable = new Sortable(widgetContainer, {
        animation: 150,
        handle: '.widget-drag-handle',
        ghostClass: 'widget-ghost',
        chosenClass: 'widget-chosen',
        dragClass: 'widget-drag',
        onEnd: function() {
            // Show save button when order changes
            if (saveLayoutBtn) {
                saveLayoutBtn.classList.remove('d-none');
            }
        }
    });

    // Initialize drag handles for all widgets
    function initializeDragHandles() {
        document.querySelectorAll('.widget').forEach(widget => {
            // Only add drag handle if it doesn't already have one
            if (!widget.querySelector('.widget-drag-handle')) {
                const header = widget.querySelector('.card-header');
                if (header) {
                    const dragHandle = document.createElement('span');
                    dragHandle.className = 'widget-drag-handle';
                    dragHandle.innerHTML = '<i class="fas fa-grip-lines me-2"></i>';
                    header.insertBefore(dragHandle, header.firstChild);
                }
            }
        });
    }

    // Save layout to localStorage
    function saveLayout() {
        const widgets = Array.from(widgetContainer.children);
        const widgetOrder = widgets.map(widget => widget.getAttribute('data-widget-id'));
        
        localStorage.setItem('dashboardWidgetOrder', JSON.stringify(widgetOrder));
        
        // Hide save button and show confirmation
        if (saveLayoutBtn) {
            saveLayoutBtn.classList.add('d-none');
            showToast('Dashboard layout saved successfully!');
        }
    }

    // Load layout from localStorage
    function loadLayout() {
        const savedOrder = localStorage.getItem('dashboardWidgetOrder');
        if (!savedOrder) return;
        
        try {
            const widgetOrder = JSON.parse(savedOrder);
            
            // Reorder widgets based on saved order
            widgetOrder.forEach(widgetId => {
                const widget = document.querySelector(`[data-widget-id="${widgetId}"]`);
                if (widget) {
                    widgetContainer.appendChild(widget);
                }
            });
        } catch (error) {
            console.error('Error loading dashboard layout:', error);
        }
    }

    // Reset layout to default
    function resetLayout() {
        localStorage.removeItem('dashboardWidgetOrder');
        location.reload();
    }

    // Show toast notification
    function showToast(message) {
        const toastContainer = document.getElementById('toast-container');
        if (!toastContainer) return;
        
        const toast = document.createElement('div');
        toast.className = 'toast show';
        toast.setAttribute('role', 'alert');
        toast.setAttribute('aria-live', 'assertive');
        toast.setAttribute('aria-atomic', 'true');
        
        toast.innerHTML = `
            <div class="toast-header">
                <i class="fas fa-check-circle text-success me-2"></i>
                <strong class="me-auto">Dashboard Customizer</strong>
                <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
            </div>
            <div class="toast-body">
                ${message}
            </div>
        `;
        
        toastContainer.appendChild(toast);
        
        // Auto-remove after 3 seconds
        setTimeout(() => {
            toast.classList.remove('show');
            setTimeout(() => {
                toast.remove();
            }, 300);
        }, 3000);
    }

    // Show/hide user guide based on first visit
    function checkFirstVisit() {
        if (localStorage.getItem('dashboardCustomizerSeen')) {
            // Hide the guide if user has seen it before
            const guide = document.getElementById('customizer-guide');
            if (guide) {
                guide.style.display = 'none';
            }
        } else {
            // Mark that user has seen the guide
            localStorage.setItem('dashboardCustomizerSeen', 'true');
        }
    }
    
    // Initialize drag handles
    initializeDragHandles();
    
    // Load saved layout
    loadLayout();
    
    // Check if this is first visit
    checkFirstVisit();
    
    // Initialize tooltips for info icons
    const tooltipTriggerList = document.querySelectorAll('[data-bs-toggle="tooltip"]');
    const tooltipList = [...tooltipTriggerList].map(tooltipTriggerEl => new bootstrap.Tooltip(tooltipTriggerEl));
    
    // Event listeners
    if (saveLayoutBtn) {
        saveLayoutBtn.addEventListener('click', saveLayout);
    }
    
    if (resetLayoutBtn) {
        resetLayoutBtn.addEventListener('click', resetLayout);
    }
});