/**
 * Mobile Tables JS
 * Transforms regular tables into mobile-friendly card views
 * MAD Pitstop - Mobile Optimization
 */
document.addEventListener('DOMContentLoaded', function() {
  // Convert tables to mobile card layout
  const tables = document.querySelectorAll('.mobile-card-table table');
  
  tables.forEach(function(table) {
    const headerCells = table.querySelectorAll('thead th');
    const headerTexts = Array.from(headerCells).map(cell => cell.textContent.trim());
    
    const rows = table.querySelectorAll('tbody tr');
    
    rows.forEach(function(row) {
      const cells = row.querySelectorAll('td');
      
      cells.forEach(function(cell, index) {
        if (index < headerTexts.length) {
          cell.setAttribute('data-label', headerTexts[index]);
        }
      });
    });
  });
  
  // Add swipe detection for tables with many columns
  const tableResponsive = document.querySelectorAll('.table-responsive');
  
  tableResponsive.forEach(function(container) {
    // Add hint for users to know the table is scrollable
    const scrollHint = document.createElement('div');
    scrollHint.className = 'text-center text-muted small mt-2 mb-1';
    scrollHint.innerHTML = '<i class="fas fa-arrows-left-right me-1"></i> Swipe to see more';
    
    // Only add the hint if the table is wider than its container
    const table = container.querySelector('table');
    if (table && table.offsetWidth > container.offsetWidth) {
      container.parentNode.insertBefore(scrollHint, container.nextSibling);
    }
    
    // Add visual indicator when scrolling the table
    container.addEventListener('scroll', function() {
      const maxScroll = container.scrollWidth - container.clientWidth;
      const currentScroll = container.scrollLeft;
      
      if (currentScroll === 0) {
        container.classList.add('at-start');
        container.classList.remove('at-end');
      } else if (Math.ceil(currentScroll) >= maxScroll - 5) {
        container.classList.add('at-end');
        container.classList.remove('at-start');
      } else {
        container.classList.remove('at-start', 'at-end');
      }
    });
    
    // Trigger the scroll event initially to set the proper classes
    container.dispatchEvent(new Event('scroll'));
  });
  
  // Enhance table interactions
  document.querySelectorAll('table').forEach(function(table) {
    // Make entire row clickable if it has a data-href attribute
    const clickableRows = table.querySelectorAll('tr[data-href]');
    clickableRows.forEach(function(row) {
      row.classList.add('clickable-row');
      row.addEventListener('click', function() {
        window.location.href = this.dataset.href;
      });
    });
    
    // Add hover effect for touchable rows
    const allRows = table.querySelectorAll('tbody tr');
    allRows.forEach(function(row) {
      row.addEventListener('touchstart', function() {
        this.classList.add('row-touched');
      });
      
      row.addEventListener('touchend', function() {
        this.classList.remove('row-touched');
      });
    });
  });
});