// Form validation script
document.addEventListener('DOMContentLoaded', function() {
    'use strict';

    // Fetch all forms we want to apply validation to
    const forms = document.querySelectorAll('.needs-validation');

    // Loop over them and prevent submission
    Array.from(forms).forEach(form => {
        form.addEventListener('submit', event => {
            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
            }
            
            form.classList.add('was-validated');
        }, false);
    });

    // Handle "No Next Hire Date" checkbox
    const noNextHireDateCheckbox = document.getElementById('no_next_hire_date');
    const nextHireDateInput = document.getElementById('next_hire_date');
    const nextHireLengthInput = document.getElementById('next_hire_length');
    
    if (noNextHireDateCheckbox && nextHireDateInput) {
        console.log('Found No Next Hire Date checkbox and next hire date input');
        
        // Check initial state
        if (noNextHireDateCheckbox.checked) {
            console.log('Checkbox initially checked, disabling date fields');
            nextHireDateInput.value = '';
            nextHireDateInput.disabled = true;
            if (nextHireLengthInput) {
                nextHireLengthInput.value = '';
                nextHireLengthInput.disabled = true;
            }
        }
        
        noNextHireDateCheckbox.addEventListener('change', function() {
            if (this.checked) {
                console.log('Checkbox checked, disabling date fields');
                nextHireDateInput.value = '';
                nextHireDateInput.disabled = true;
                if (nextHireLengthInput) {
                    nextHireLengthInput.value = '';
                    nextHireLengthInput.disabled = true;
                }
            } else {
                console.log('Checkbox unchecked, enabling date fields');
                nextHireDateInput.disabled = false;
                if (nextHireLengthInput) {
                    nextHireLengthInput.disabled = false;
                }
            }
        });
    } else {
        console.log('No Next Hire Date checkbox or next hire date input not found');
    }

    // Set today as the default for date fields if they're empty
    const dateFields = document.querySelectorAll('input[type="date"]');
    const today = new Date().toISOString().split('T')[0];

    dateFields.forEach(field => {
        if (!field.value && !field.disabled) {
            // Only set date for next_hire_date if it's that field
            if (field.id === 'next_hire_date' && !noNextHireDateCheckbox?.checked) {
                field.value = today;
            }
        }
    });

    // No need to validate fuel and adblue levels as they are now selects with predefined values

    // Convert registration to uppercase
    const regoInput = document.getElementById('rego');
    if (regoInput) {
        regoInput.addEventListener('blur', function() {
            this.value = this.value.toUpperCase();
        });
    }
});
